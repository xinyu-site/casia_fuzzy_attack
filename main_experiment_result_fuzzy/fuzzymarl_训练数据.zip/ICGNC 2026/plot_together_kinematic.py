import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

tasks = [
    'Rendezvous',
    'Pursuit',
    'Collection',
]

setting = 'test'  # 'test'

sns.set()
flatui = [
    "#4e79a7",   # ablation color
    "#f28e2b", 
    "#59a14f",   # ablation color
    # "#76b7b2",
    "#9c66b0",   # ablation color
    "#9c755f",   # ablation color
    "#e15759",   # ablation color
]
sns.set_palette(sns.color_palette(flatui))

fig, axs = plt.subplots(1, 3, figsize=(24, 6), gridspec_kw={'wspace': 0.15})

all_handles = []
all_labels = []
for idx, task in enumerate(tasks):
    path = os.path.join('data_for_plot', task, setting + '.csv')
    df = pd.read_csv(path)
    ax = axs[idx]

    # 只让第一个有图例，其余都去掉
    p = sns.lineplot(
        x="Step",
        y="Episode Rewards",
        hue="algo",
        style="algo",
        data=df,
        ax=ax,
        linewidth=1.5,
        legend=True,
        dashes=False,
    )
    if idx == 0:
        handles, labels = ax.get_legend_handles_labels()
        all_handles, all_labels = handles, labels
    
    # 运动学
    ax.set_ylabel('Episode Rewards', fontsize=15)
    # smac
    # ax.set_ylabel('Win Rate', fontsize=15)
    ax.set_xlabel('Step', fontsize=15)
    ax.tick_params(labelsize=13)
    ax.set_title(task, fontsize=16)
    ax.get_legend().remove()
    if idx != 0:
        ax.set_ylabel('')

# 调整主图布局，为下方图例腾空间
plt.tight_layout(rect=[0, 0.11, 1, 1])  # rect[1]=底部留11%空白

# fig.legend 只调一次
fig.legend(
    all_handles, all_labels,
    loc='lower center',
    ncol=len(all_labels),
    fontsize=15,
    frameon=False,
    bbox_to_anchor=(0.5, 0.015)   # 这个0.015位置是适合21x6的，你可以微调
)

plt.subplots_adjust(bottom=0.19)  # 进一步保障下方空间

save_name = os.path.join('fig', setting + '_' + 'kinematic' + '.pdf')
plt.savefig(save_name, format="pdf", bbox_inches='tight')
# plt.show()