import pandas as pd
import os

raw_data_dir = 'current'
save_dir = 'data_for_plot'

algo_map = {
    'mappo': 'MAPPO',
    'gat_mappo': 'GAT',
    'gcn_mappo': 'GCN',
    'graphsage_mappo': 'MAGEC',
    'egnnv2_mappo': 'EGNN',
    'mappo_data_aug': 'AUG',
    'egnn_mix_mappo': 'EGNNMIX'
}

# ablation algo map
# algo_map = {
#     'gnn': 'HSIN w/o H&S',
#     'hie_mappo': 'HSIN w/o S',
#     'hie_critic_mappo': 'HSIN w/o S',
#     'egn_mappo': 'HSIN w/o H',
#     'egnn_critic_happo': 'HSIN w/o SE',
#     'egnnv3_mappo': 'HSIN w/o SE',
#     'egm_mappo': 'HSIN w/o M',
#     'eghn_critic_mappo': 'HSIN w/o M',
#     'hsin_mappo': 'HSIN',
#     'eghn_critic_happo': 'HSIN',
# }

task_map = {
    'navigation': 'Collection',
    'pursuit': 'Pursuit',
    'rendezvous': 'Rendezvous',
}


for task in os.listdir(raw_data_dir):
    task_path = os.path.join(raw_data_dir, task)
    for name in os.listdir(task_path):
        task_data = pd.DataFrame()
        name_path = os.path.join(task_path, name)
        for algo in algo_map:
            data_path = os.path.join(name_path, algo)
            if os.path.exists(data_path):
                for filename in os.listdir(data_path):
                    file_path = os.path.join(data_path, filename)
                    data = pd.read_csv(file_path)
                    # if task == 'rendezvous':
                    #     data = data[:100]
                    data['algo'] = algo_map[algo]
                    
                    # 平滑数据    
                    if task == 'rendezvous':
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=2, min_periods=1).mean()
                        # pass
                    elif task == 'navigation':
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=2, min_periods=1).mean()
                    elif task == 'pursuit':
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=10, min_periods=1).mean()

                    task_data = pd.concat([task_data, data], ignore_index=True) 
        save_path = os.path.join(save_dir, task_map[task])
        os.makedirs(save_path, exist_ok=True)
        task_data.to_csv(os.path.join(save_path, name + '.csv'))
