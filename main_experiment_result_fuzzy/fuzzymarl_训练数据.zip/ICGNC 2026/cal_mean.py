import pandas as pd
import os

raw_data_dir = 'csv_data_eswa'

algo_map = {
    # 'mappo': 'MAPPO',
    # 'gat_mappo': 'InfoMARL',
    # # 'gcn_mappo': 'GPG',
    # 'graphsage_mappo': 'MAGEC',
    # # 'gcs': 'GCS',
    # 'mappo_data_aug': 'ESP',
    # 'egnn_mappo': 'E2GN2',
    # 'egnnv2_mappo': 'E2GN2',
    # 'egnn_critic_mappo': 'E2GN2',
    # 'hepn_mappo': 'HEPN',

    # 'gnn': 'HSIN w/o H&S',
    # 'hie_mappo': 'HSIN w/o S',
    # 'hie_critic_mappo': 'HSIN w/o S',
    # 'egn_mappo': 'HSIN w/o H',
    # 'egnn_critic_happo': 'HSIN w/o SE',
    # 'egnnv3_mappo': 'HSIN w/o SE',

    # 'eghn_critic_mappo': 'HSIN',
    # 'hsin_mappo': 'HSIN',
    # 'eghn_critic_happo': 'HSIN',
    'mappo': 'MAPPO',
    'gat_mappo': 'InfoMARL',
    'graphsage_mappo': 'MAGEC',
    'mappo_data_aug': 'ESP',
    'hmf_mappo': 'HMF',
    'hama_mappo': 'HAMA',
    'egnn_mappo': 'E2GN2',
    'egnnv2_mappo': 'E2GN2',
    'egnn_critic_mappo': 'E2GN2',
    'hepn_mappo': 'HEPN',    
    'hsin_mappo': 'HSIN',
    'eghn_critic_happo': 'HSIN',
}

task_map = {
    'navigation': 'Resource Collection',
    'pursuit': 'Pursuit',
    'rendezvous': 'Rendezvous',
    '3d_hoppers': '3D Hoppers',
    '3d_walkers': '3D Walkers',
    '3d_humanoids': '3D Humanoids',
    'protoss_5_vs_5': 'Protoss 5v5',
    'terran_5_vs_5': 'Terran 5v5',
    'zerg_5_vs_5': 'Zerg 5v5',
    'protoss_10_vs_10': 'Protoss 10v10',
    'terran_10_vs_10': 'Terran 10v10',
    'zerg_10_vs_10': 'Zerg 10v10',
}

for task in os.listdir(raw_data_dir):
    task_path = os.path.join(raw_data_dir, task)
    for name in os.listdir(task_path):
        name_path = os.path.join(task_path, name)
        for algo in algo_map:
            algo_data = pd.DataFrame()
            data_path = os.path.join(name_path, algo)
            if os.path.exists(data_path):
                v = 0
                for filename in os.listdir(data_path):
                    file_path = os.path.join(data_path, filename)
                    data = pd.read_csv(file_path)
                    data['algo'] = algo_map[algo]
                    
                    algo_data = pd.concat([algo_data, data], ignore_index=True) 
                # 读取均值方差
                # if task == 'rendezvous' and name == 'test40':
                #     top = algo_data['Episode Rewards'].nlargest(50)
                #     mean = round(top.mean(), 1)
                #     std = round(top.std(), 1)
                #     print("{} {} : ${} \pm {}$ {}".format(task, name, mean, std, algo))
                # if task == 'pursuit' and name == 'test':
                #     top = algo_data['Episode Rewards'].nlargest(2000)
                #     mean = round(top.mean(), 1)
                #     std = round(top.std(), 1)
                #     print("{} {} : ${} \pm {}$ {}".format(task, name, mean, std, algo))
                # if task == 'navigation' and name == 'test':
                #     top = algo_data['Episode Rewards'].nlargest(500)
                #     mean = round(top.mean(), 1)
                #     std = round(top.std(), 1)
                #     print("{} {} : ${} \pm {}$ {}".format(task, name, mean, std, algo))
                if task == 'zerg_5_vs_5' and name == 'test':
                    top = algo_data['Episode Rewards'].nlargest(200) * 100
                    mean = round(top.mean(), 1)
                    std = round(top.std(), 1)
                    print("{} {} : ${} \pm {}$ {}".format(task, name, mean, std, algo))

