import os
import numpy as np
import matplotlib.pyplot as plt

def moving_average(data, window_size=10):
    """滑动平均，用于平滑曲线"""
    return np.convolve(data, np.ones(window_size) / window_size, mode='valid')

def load_curve(file_path):
    """根据文件类型加载训练曲线"""
    if file_path.endswith('.npz'):
        data = np.load(file_path)
        return data['Step'], data['Episode_Rewards']
    elif file_path.endswith('.npy'):
        data = np.load(file_path, allow_pickle=True).item()
        return data['Step'], data['Episode_Rewards']
    elif file_path.endswith('.csv'):
        data = np.genfromtxt(file_path, delimiter=',', names=True)
        return data['Step'], data['Episode_Rewards']
    else:
        raise ValueError(f"不支持的文件类型: {file_path}")

def plot_all_curves(folder_path, smooth_window=10):
    plt.figure(figsize=(10, 6))

    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            steps, returns = load_curve(file_path)

            # 为了让steps和returns长度一致，做裁剪
            if len(steps) > len(returns):
                steps = steps[:len(returns)]
            elif len(returns) > len(steps):
                returns = returns[:len(steps)]

            smoothed_returns = moving_average(returns, smooth_window)
            smoothed_steps = steps[:len(smoothed_returns)]  # 对应裁剪

            plt.plot(smoothed_steps, smoothed_returns, label=f'Seed: {filename}')
        except Exception as e:
            print(f"跳过文件 {filename}，出错信息：{e}")
            continue

    plt.xlabel("Training Steps")
    plt.ylabel("Return")
    plt.title("Smoothed Training Curves for Different Seeds")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# 调用：替换成你的文件夹路径，windows下需要换掉斜线
plot_all_curves("D:\\PycharmProjects\\plot\\ICGNC 2026\\csv_data_icgnc\\navigation\\test\\gat_mappo", smooth_window=10)