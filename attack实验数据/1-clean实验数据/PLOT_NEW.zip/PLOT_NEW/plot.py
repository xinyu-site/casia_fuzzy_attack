import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os

tasks = [
    #'rendezvous',
    'pursuit',
    # 'navigation',
    # '3d_hoppers',
    # '3d_humanoids',
    # '3d_walkers',
    # 'terran_5_vs_5',
    # 'zerg_5_vs_5',
    # 'protoss_5_vs_5',
    ]


for task in tasks:
    path = os.path.join('data_for_plot', task,  'test.csv')
    df = pd.read_csv(path)
    sns.set()
    # flatui = ["navy", "gold", "darkgreen", "firebrick"]
    # flatui = ["darkgoldenrod", "darkgreen", "navy", "firebrick"]
    flatui = [
        # "#1f77b4",  # 蓝色（默认）
        # "#ff7f0e",  # 橙色
        # "#2ca02c",  # 绿色
        # "#9467bd",  # 紫色
        # "#8c564b",  # 棕色
        # "#17becf",  # 青色
        # "#d62728",  # 红色
        
        "#4e79a7",  # 温和的蓝色
        "#f28e2b",  # 柔和的橙色
        "#59a14f",  # 清新的绿色
        "#76b7b2",  # 柔和的青色
        "#9c66b0",  # 温暖的紫色
        "#9c755f",  # 温暖的棕色
        "#e2b71d",  # 柔和的金黄色
        "#e15759",  # 柔和的红色
    ]
    sns.set_palette(sns.color_palette(flatui))
    fig, ax = plt.subplots()
    

    # 需要手动改dashes
    sns.lineplot(x="Step", y="Episode Rewards", hue="algo", style="algo", dashes=["", "", "", "", "", "", "", ""], data=df, ax=ax)
    # sns.lineplot(x="Step", y="Value", data=df)
    sns.set_context("paper")
    handles, labels = ax.get_legend_handles_labels()
    # ax.legend(handles=handles[1:], labels=labels[1:])
    ax.legend(handles=handles[::-1], labels=labels[::-1], loc='lower right', bbox_to_anchor=(1, 0))
    # ax.set_ylabel('Episode Rewards', fontsize=15)
    # 用于smac
    ax.set_ylabel('Win Rate', fontsize=15)
    ax.set_xlabel('Step', fontsize=15)
    # ax.set_ylim(-100, 400)
    ax.tick_params(labelsize=15)
    plt.legend(fontsize=13)
    # plt.title("")
    save_name = os.path.join('fig', '_' + task+ '.pdf')
    plt.savefig(save_name, format="pdf", bbox_inches='tight')
    # save_name = os.path.join('fig', setting + '_' + task + '.png')
    # plt.savefig(save_name, format="png", bbox_inches='tight')