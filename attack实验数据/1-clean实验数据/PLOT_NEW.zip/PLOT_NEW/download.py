import tensorflow as tf
import os
import re
import csv

log_file_path = "D:/PycharmProjects/plot/ECAI24/results_194/pursuit/global-direct-tac/mappo/ecai_10/seed-00000-2024-04-01-05-24-56"
log_file_path += "/logs/train_episode_rewards/aver_rewards/"
for filename in os.listdir(log_file_path):
    log_file = log_file_path + filename
match = re.search(r'results_194/([^/]+)/([^/]+)/([^/]+)/([^/]+)', log_file_path)
task, setting, algorithm, name = match.groups()
seed_number = int(re.search(r'seed-([^-]+)', log_file_path).group(1))

csv_file_dir = os.path.join('csv_data', task, name, algorithm)
os.makedirs(csv_file_dir, exist_ok=True)

csv_file_path = os.path.join(csv_file_dir, 'seed_' + str(seed_number)) + '.csv'

with open(csv_file_path, mode='w', newline='') as file:
    writre = csv.writer(file)
    writre.writerow(['Step', 'Episode Rewards'])
    for e in tf.compat.v1.train.summary_iterator(log_file):
        for v in e.summary.value:
            writre.writerow([e.step, v.simple_value])
