# import numpy as np
# import matplotlib.pyplot as plt
# import seaborn as sns


# # sns.set()
# coord = np.load('tra/navi1.npy')
# tra_x = coord[0]
# tra_y = coord[1]
# print(tra_x.shape, tra_y.shape)

# end = np.array([
#     [254, 135, 144],  # 玫瑰红
#     [254, 135, 144],  # 玫瑰红
#     [55, 179, 213],   # 青绿
#     [55, 179, 213],   # 青绿
#     [55, 179, 213],   # 青绿
#     [227, 181, 68], 
#     [227, 181, 68], 
#     # [139, 98, 124],
#     # [159, 160, 160],
#     # [90, 189, 236],
#     # [218, 79, 16],
#     # [159, 160, 160],
#     # [159, 160, 160],
#     # [115, 172, 45],
#     # [126, 30, 134],
#     # [237, 184, 3],
#     # [4, 108, 183],
#     # [82, 176, 167],
#     # [183, 40, 82]
#     ]) / 255
# star = np.array([
#     [254, 76, 89],
#     [254, 76, 89],

#     [34, 131, 158],
#     [34, 131, 158],
#     [34, 131, 158],

#     [197, 149, 29],
#     [197, 149, 29],
#     # [69, 47, 62],
#     # [101, 100, 100],
#     # [14, 92, 121],
#     # [117, 41, 8],
#     # [101, 100, 100],
#     # [101, 100, 100],
#     # [60, 91, 34],
#     # [61, 18, 71],
#     # [128, 93, 22],
#     # [1, 53, 94],
#     # [40, 94, 85],
#     # [98, 16, 43]
#     ]) / 255
# start = np.array([
#     [255, 235, 236],
#     [255, 235, 236],
    
#     [214, 239, 246],
#     [214, 239, 246],
#     [214, 239, 246],

#     [227, 181, 68], 
#     [227, 181, 68], 
#     # [251, 250, 252],
#     # [241, 241, 241],
#     # [246, 251, 254],
#     # [254, 250, 248],
#     # [241, 241, 241],
#     # [241, 241, 241],
#     # [248, 251, 242],
#     # [239, 228, 240],
#     # [254, 251, 237],
#     # [240, 247, 252],
#     # [247, 251, 251],
#     # [252, 246, 249]
#     ]) / 255
# n = tra_x.shape[0]

# for i in range(tra_x.shape[1]):
#     for j in range(n):
#         # if j % 2 != 0:
#         #     continue
#         # if (j * 4 / 3) % 10 != 0:
#         #     continue
#         rgb = (end[i] - start[i]) / n * j + start[i]
#         plt.plot(tra_x[j, i], tra_y[j, i], marker='o', color=rgb.tolist(), markersize=20, alpha=0.7)
#     plt.plot(tra_x[:, i], tra_y[:, i], linewidth=1.0, color=end[i].tolist())
#     plt.plot(tra_x[n - 1, i], tra_y[n - 1, i], marker='*', color=star[i].tolist())
# # plt.plot(0, 0, marker='o', markersize=20, color=[0, 0, 0])
# # plt.plot(0.5, 0.5, marker='o', markersize=20, color=[0, 0, 0])
# # plt.plot(0.5, -0.5, marker='o', markersize=20, color=[0, 0, 0])
# # plt.plot(-0.5, 0.5, marker='o', markersize=20, color=[0, 0, 0])
# # plt.plot(-0.5, -0.5, marker='o', markersize=20, color=[0, 0, 0])
# # plt.gca().set_aspect(1)
# plt.xlabel('x(m)')
# plt.ylabel('y(m)')
# plt.savefig("fig/navi1.pdf", format="pdf", bbox_inches='tight')


# import numpy as np
# import matplotlib.pyplot as plt
# from scipy.interpolate import CubicSpline
# from matplotlib.colors import Normalize
# from matplotlib.cm import ScalarMappable
# import seaborn as sns

# real_corner = [(-1112, -1568), (1711, -1568), (1711, 1255), (-1112, 1255)]


# def map_to_virtual(real_point, real_corners, world_size):
#     # virtual_point = np.zeros((1, 2))
#     bl, br, tr, tl = real_corners
#     bl = np.array(bl)
#     br = np.array(br)
#     tr = np.array(tr)
#     tl = np.array(tl)
#     x_rate = float(br[0] - bl[0])
#     y_rate = float(tl[1] - bl[1])
#     x = real_point[0]
#     x = np.clip(x, bl[0], br[0])
#     y = real_point[1]
#     y = np.clip(y, bl[1], tl[1])
#     # virtual_point[0, 0] = (x - bl[0]) / x_rate * world_size
#     # virtual_point[0, 1] = (y - bl[1]) / y_rate * world_size
#     x_coord = (x - bl[0]) / x_rate * world_size
#     y_coord = (y - bl[1]) / y_rate * world_size
#     return x_coord, y_coord


# sns.set()
# data = np.load('tra/rend1.npy')

# # 创建图和轴
# fig, ax = plt.subplots(figsize=(10, 8))
# cmap = plt.get_cmap('viridis')
# norm = Normalize(vmin=0, vmax=data.shape[1])
# end = np.array([55, 179, 213]) / 255,  
# start = np.array([214, 239, 246]) / 255
# star = np.array([34, 131, 158],) / 255

# # 遍历每一个智能体
# for agent_idx in range(data.shape[2]):
#     # x_coords = data[0, :, agent_idx]
#     # y_coords = data[1, :, agent_idx]

#     x_coords, y_coords = map_to_virtual(data[:, :, agent_idx], real_corner, 100)

#     # 为每条轨迹生成更平滑的点
#     t = np.linspace(0, 1, len(x_coords))  # 创建一个参数t，用于插值
#     cs_x = CubicSpline(t, x_coords)  # x坐标的三次样条插值
#     cs_y = CubicSpline(t, y_coords)  # y坐标的三次样条插值

#     # 生成细分后的更平滑的t值
#     t_fine = np.linspace(0, 1, 300)
#     x_smooth = cs_x(t_fine)
#     y_smooth = cs_y(t_fine)

#     # 绘制平滑轨迹
#     for i in range(1, len(t_fine)):
#         alpha = 0.1 + 0.9 * (i / len(t_fine))
#         color = start + (end - start) * (i / len(t_fine))
#         # color = cmap(norm(i))
#         linewidth = 2 + 20 * (i / len(t_fine))
#         ax.plot(x_smooth[i-1:i+1], y_smooth[i-1:i+1], '-', color=color, alpha=alpha, linewidth=linewidth, 
#                 solid_capstyle='round')
#     ax.scatter(x_smooth[-1], y_smooth[-1], color=star, s=1000, edgecolor=star, zorder=5)
#     ax.set_ylim(-10, 90)
#     ax.set_xlim(-10, 90)
# # 设置图表标题和坐标轴标签
# # ax.set_title('多智能体轨迹图（颜色渐变与透明度变化，圆形端点）')
# # ax.set_xlabel("X 坐标")
# # ax.set_ylabel('Y 坐标')
# # ax.set_aspect('equal')

# # 显示图表
# plt.show()


import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import interp1d
from matplotlib.patches import FancyArrowPatch

# Load trajectory data
trajectory_data = np.load('pur1.npy')  # Replace 'pur1.npy' with the actual path to your data

# Check the shape of the data to understand how it is organized
print("Data shape:", trajectory_data.shape)

# Assuming the data is organized with dimensions (2, 47, 5)
# - First dimension is likely for x and y coordinates
# - Second dimension is the number of timesteps
# - Third dimension is the number of agents

# Initialize an array to store the corrected data format (5 agents, 47 timesteps, 2 coordinates)
# Rearranging so that agent 4 (prey) comes first
order = [3, 0, 1, 2, 4]  # Bring the 4th agent (prey) to the first position
corrected_data = np.empty((5, trajectory_data.shape[1], 2))

for i, idx in enumerate(order):
    corrected_data[i, :, 0] = trajectory_data[0, :, idx]  # X coordinates
    corrected_data[i, :, 1] = trajectory_data[1, :, idx]  # Y coordinates

# Define the styles and colors for the plot
colors = ['deepskyblue', 'darkred', 'darkred', 'darkred', 'darkred']  # Blue for prey, red for predators
line_styles = ['-', '--', '--', '--', '--']  # Solid line for prey, dashed lines for predators

plt.figure(figsize=(10, 8))

# Create a dictionary to handle the legend entries to avoid duplicates
legend_entries = {}

# Number of points for interpolation
num_points = 200

for i in range(5):
    x_vals = corrected_data[i, :, 0]
    y_vals = corrected_data[i, :, 1]

    # Interpolate for smoother curves
    t = np.linspace(0, 1, len(x_vals))
    t_new = np.linspace(0, 1, num_points)
    f_x = interp1d(t, x_vals, kind='cubic')
    f_y = interp1d(t, y_vals, kind='cubic')
    x_smooth = f_x(t_new)
    y_smooth = f_y(t_new)

    label = 'Prey' if i == 0 else 'Predator'
    line, = plt.plot(x_smooth, y_smooth, linestyle=line_styles[i], linewidth=2, color=colors[i], label=label if label not in legend_entries else "")
    # Mark the start point with a large