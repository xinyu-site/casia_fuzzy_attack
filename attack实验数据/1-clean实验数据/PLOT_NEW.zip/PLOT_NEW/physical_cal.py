import json
import numpy as np
# hepn_navi_path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/navigation_tyk0422_14.json'
# baseline_navi_path_ = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/navigation_tyk0422_15.json'

# hepn_pur_path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/pur_tyk/pursuit_0420_1.json'
# baseline_pur_path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/pur_tyk/pursuit_0420_2.json'

# hepn_rend_path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/rend_tyk/rendezvous_0420_3.json'
# baseline_rend_path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/rend_tyk/rendezvous_tyk0424_4.json'

target1 = np.array([-487, 764])
target2 = np.array([1486, -1148])
first = ["limo7489", "limo9185"]
second = ["limo7490", "limo9067", "limo7506"]

path = 'D:/PycharmProjects/plot/ECAI24/coord_data_422/pur_tyk/pursuit_0420_2.json'
with open(path, 'r') as file:
    tra = json.load(file)

# for pursuit
dis = 0
evader = "limo9070"
tra = tra[:25]
for i in range(len(tra)):
    if i == 0:
        continue
    for key in tra[i]:
        if key != evader:
            coord1 = np.array(tra[i - 1][key][:2])
            coord2 = np.array(tra[i][key][:2])
            dis += np.linalg.norm(coord2 - coord1)
print(dis/10)

# for other tasks
# dis = 0
# for i in range(len(tra)):
#     if i == 0:
#         continue
#     for key in tra[i]:
#         coord1 = np.array(tra[i - 1][key][:2])
#         coord2 = np.array(tra[i][key][:2])
#         dis += np.linalg.norm(coord2 - coord1)
# print(dis/10)

# 将轨迹顺时针旋转90度保存为npy
# X = []
# Y = []
# rotation_matrix = np.array([[0, 1], 
#                             [-1,  0]])
# # tra = tra[:24]
# for t in tra:
#     x = []
#     y = []
#     for key in t:
#         t[key][:2] = rotation_matrix.dot(t[key][:2])
#         x.append(t[key][0])
#         y.append(t[key][1])
#     X.append(x)
#     Y.append(y)
# coord = np.array([X, Y])
# np.save('tra/navi2.npy', coord)