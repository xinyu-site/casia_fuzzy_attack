import pandas as pd
import os

raw_data_dir = 'trans_csv_data'
save_dir = 'data_for_plot'

algo_map = {
    'mappo': 'MAPPO',
    'gat_mappo': 'InfoMARL',
    'gcn_mappo': 'GPG',
    'graphsage_mappo': 'MAGEC',
    #'gcs': 'GCS',
    'mappo_data_aug': 'ESP',
    #'egnn_mappo': 'E2GN2',
    'egnnv2_mappo': 'E2GN2',
    #'hepn_mappo': 'HSIN',
    # 'eghnv2_mappo': 'HSIN',
    # 'eghn_critic_mappo': 'HEPN_Critic',
    # 'eghn_actor_mappo': 'HEPN_Actor',
    # 'egnn_critic_mappo': 'EGNN_Critic',
    # 'eghn_critic_happo': 'HEPN_Critic_Happo',
    # 'rnn': 'RNN',

}
a = 0
for task in os.listdir(raw_data_dir):
    task_path = os.path.join(raw_data_dir, task)
    for name in os.listdir(task_path):
        task_data = pd.DataFrame()
        name_path = os.path.join(task_path, name)
        for algo in algo_map:
            data_path = os.path.join(name_path, algo)
            if os.path.exists(data_path):
                v = 0
                for filename in os.listdir(data_path):
                    file_path = os.path.join(data_path, filename)
                    data = pd.read_csv(file_path)
                    data['algo'] = algo_map[algo]
                    # v += data['Episode Rewards'].nlargest(10).mean()
                    if task == 'rendezvous':
                        data = data[:150]
                    # if task == '3d_hoppers':
                    #     data = data[:501]
                # if name == 'ecai_10' and algo == 'mappo':
                #     print(task, algo_map[algo], v / 5)
                #     if name == 'hie' and algo == 'egnn_mappo':
                #         del data['Wall time']
                #         data.columns = ['Step', 'Episode Rewards']
                #         data.to_csv(file_path, index=False)
                #     if name == 'ecai_10' or name == 'hie':
                #         if task == 'rendezvous':
                #             if 'gcs' in algo:
                #                 data = data[:150]
                #             else:
                #                 data = data[:250]
                #             data['Episode Rewards'] = data['Episode Rewards'].rolling(window=3, min_periods=1).mean()
                #         elif task == 'navigation':
                #             data['Episode Rewards'] = data['Episode Rewards'].rolling(window=15, min_periods=1).mean()
                #         else:
                #             data['Episode Rewards'] = data['Episode Rewards'].rolling(window=20, min_periods=1).mean()
                    # if task == 'mujoco3d':
                    # 平滑数据    
                    if task == 'rendezvous':
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=1, min_periods=1).mean()
                    elif task == 'navigation':
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=2, min_periods=1).mean()
                    else:
                        data['Episode Rewards'] = data['Episode Rewards'].rolling(window=5, min_periods=1).mean()
                    task_data = pd.concat([task_data, data], ignore_index=True) 
        save_path = os.path.join(save_dir, task)
        os.makedirs(save_path, exist_ok=True)
        task_data.to_csv(os.path.join(save_path, name + '.csv'))
